This directory is for a few additional options for YUNG's Better Caves.
Options provided may vary by version.
This directory contains subdirectories for supported versions. The first time you run Better Caves, a version subdirectory will be created if that version supports advanced options.
For example, the first time you use Better Caves for MC 1.21.1 on Fabric, the 'fabric-1_21_1' subdirectory will be created in this folder.
If no subdirectory for your version is created, then that version probably does not support the additional options.